Coupons Feed
============

This is a simple script to:

1. Pull the coupons XML that the professional team provides through a stored MSSQL procedure
2. Validate the returned XML against a schema
3. Write the feed output to a file on img.webmd.com

Prerequisites
-------------
This script is Linux-only and requires these utilities:

* [xmllint](http://xmlsoft.org/xmllint.html) - this comes installed on Red Hat Enterprise
* [Microsoft SQL Server ODBC Driver 1.0 for Linux](http://www.microsoft.com/en-us/download/details.aspx?id=28160)

Setup
-----
Copy config.sample to config:

`cp config.sample config`

Open in a text editor and fill in the appropriate values to connect to the Coupons database.

If you are testing outside the default directories, you may need to make pull.sh executable:

`chmod +x pull.sh`

Executing
---------
`/opt/webmd/webdev/coupons-feed/pull.sh`

A cron job will run this script every 24 hours on cnslx01d-con-08.portal.webmd.com soon.

Deployment/Testing
------------------
You should test changes to this script on cnslx02d-con-08.portal.webmd.com, then deploy to cnslx01d-con-08.portal.webmd.com. In both cases, the local filesystem path to the script is /opt/webmd/webdev/coupons-feed.

#!/bin/bash

#
# Function to handle error display, logging, and mail
#
error()
{
	ERROR="Error: $1"
	echo $ERROR
	echo -e $ERROR | /bin/mail -s "[$SERVER] /opt/webmd/webdev/coupons-feed/pull.sh failed" "$ERRORTOEMAIL" -- -f $ERRORFROMEMAIL 
	exit 1
}

#
# Function to verify a command exists
#
verifycmd()
{
	type $1 &>/dev/null
	if [ $? -eq 0 ];then
		return 0
	else
		error "$1 does not appear to exist on this system"
	fi
}

#
# Load the config                                               #
#
if [ -f config ];then
	. config
	echo Loaded config...
else
	error "No config file found"
fi

#
# Check for needed commands                                     
#                                                               
# sqlcmd is installed along with Microsoft's MSSQL driver       
# for Linux:                                                    
# http://www.microsoft.com/en-us/download/details.aspx?id=28160 
#                                                               
# xmllint comes with RHE5                                       
#
verifycmd sqlcmd
verifycmd xmllint
echo Verified necessary utilities are available...

#
# Load the config                                               #
#
if [ -f config ];then
	. config
	echo Loaded config...
else
	error "No config file found"
fi

#
# Run mssql query to pull xml, exit if it fails
#
sqlcmd -U "$DBUSER" -P "$DBPW" -d "$DBNAME" -S "$DBSERVER" -o pull.xml -Q "EXECUTE $DBPROC;" -y 0
if [ $? -eq 0 ];then
	echo Pulled XML from MSSQL...
else
	error "Failed to pull XML from MSSQL"
fi

#
# Verify code structure with xmllint
#
xmllint --noout --schema schema.xsd ./pull.xml &>/dev/null
if [ $? -eq 0 ];then
	echo Validated XML against schema...
else
	error "XML failed to validate against schema.xsd"
fi

#
# Move file 
#
mv -f pull.xml "$XMLPATH" &>/dev/null
if [ $? -eq 0 ];then
	echo Deployed file to $XMLPATH
else
	error "Failed to deploy XML to $XMLPATH"
fi

$(function() {
	
	// A-Z
	$('.couponsaz').each(function() {
		var couponsAZ = webmd.object(webmd.m.couponsAZ);
		couponsAZ.init(this);
	});

	// All coupons modules (A-Z or Category)
	$('.coupons').each(function() {
		var coupons = webmd.object(webmd.m.coupons);
		coupons.init(this);
	});

});
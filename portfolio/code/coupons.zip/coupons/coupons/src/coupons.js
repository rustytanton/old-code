/*! webmd.m.coupons */
if (!window.webmd) { webmd = {}; }
if (!webmd.m) { webmd.m = {}; }

webmd.m.coupons = {

	init : function(ele) {
		this.ele = ele;
		this.scrubLinks();
		$(this.ele).show();
	},

	scrubLinks : function() {
		var today = new Date();
		$(this.ele).find('a').each(function() {
			//Remove duplicates occurring because a drug belongs to multiple categories 
			var $listItem = $(this).parent();
			if ($listItem.text()==$listItem.next().text()) {
				$listItem.next().remove();
			}
			
			//Remove expired coupons
			var attr = $(this).data('end');
			var neverexpires = $(this).data('neverexpires') === 1;
			if (attr) {
				// cleaning up the date string because Safari can't read YYYY/MM/DD
				var attr = attr.replace(/-/g,"/");
				var attr = attr.replace("T"," ");
				var expire = new Date(attr);
				if (expire.getTime() < today.getTime() && !neverexpires) {
					$(this).parent().remove();
				}
			}
		});
	}

};
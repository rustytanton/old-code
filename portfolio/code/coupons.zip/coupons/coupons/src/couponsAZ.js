/*! webmd.m.couponsAZ */
if (!window.webmd) { webmd = {}; }
if (!webmd.m) { webmd.m = {}; }

/**
 * @class Coupons A-Z module object
 * @property {String} currentLetter The current letter
 * @property {Array} letters All letters found in init script
 */
webmd.m.couponsAZ = {

	/**
	 * Instantiate a Coupons A-Z module
	 * 
	 * @param {DOM Element} ele wrapper div for Coupons A-Z HTML
	 * 
	 * @example
	 * $('.couponsaz').each(function() {
	 * 		var couponsAZ = webmd.object(webmd.m.couponsAZ);
	 * 		couponsAZ.init(this);
	 * });	
	 */
	init : function(ele) {
		this.currentLetter = '';
		this.ele = ele;
		this.letters = [];
		this.loadLetters();
		this.applyNav();
		$(this.ele).show();
	},

	/* 
	 * Loads letters into array, if the hash is different from the
	 * default first letter in the code, show the hash. Called from
	 * init, not meant to be called directly.
	 * @private
	 */
	loadLetters : function() {
		var self = this;
		var winhash = webmd.url.getHash();
		$(this.ele).find('.alpha a').each(function() {
			var linkhash = webmd.url.getHash(this.href);
			self.letters.push(linkhash);
			if ( $(this).parent().hasClass('active') ) {
				self.currentLetter = linkhash;
			}
		});
		if ( $.inArray(winhash, this.letters) > -1 ) {
			self.currentLetter = winhash;
			this.showLetter(winhash);
		}
	},

	/**
	 * Shows a list of coupons which start with a particular
	 * letter.
	 * 
	 * @param {String} letter a capital letter, i.e. 'A', 'B', 'C', etc
	 */
	showLetter : function(letter) {
		if ($.inArray(letter, this.letters) > -1) {

			// show the appropriate content
			$(this.ele).find('.list ul').removeClass('active');
			$(this.ele).find('#coupons' + letter).addClass('active');

			// highlight the appropriate nav link
			$(this.ele)
				.find('.alpha li')
				.removeClass('active')
				.each(function() {
					var linktext = $(this).find('a').text();
					if (letter == linktext) {
						$(this).addClass('active');
					}
				});

			// set the current letter
			this.currentLetter = letter;
			webmd.url.setHash(letter);
		}
	},

	/**
	 * Apply navigation events to links. Called from init, not meant
	 * to be called directly.
	 * @private
	 */
	applyNav : function() {
		var self = this;
		$(this.ele).find('.alpha a').click(function() {
			var hash = webmd.url.getHash(this.href);
			self.showLetter(hash);
			wmdPageLink( 'lln-couponbydrug_' + hash.toLowerCase() );			
		});
	}

};
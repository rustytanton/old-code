/**
 * Coupons spec
 * 
 * @uses jquery-1.4.4
 * @uses jasmine-1.1.0
 * @uses jasmine-jquery-1.3.1
 */
describe("coupons", function() {

	beforeEach(function() {

		// last known good xml
		// (this should be updated when there are changes to the DOM output,
		// copy from build/snippets/test1.xml and build/snippets/test11.xml)
		setFixtures('<div class="coupons couponsbycat"><h1>Coupons for Allergies Drugs</h1><div class="two_col_body_fmt"><ul class="col_1_fmt"><li><a onclick="return sl(this, \'nw\', \'lln-couponbycond_1\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy1" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Allergy Drug 1</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbycond_3\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy3" data-start="2010-06-24T08:26:00" data-end="2011-10-31T11:08:00" data-neverexpires="1">Allergy Drug 3</a></li></ul><ul class="col_2_fmt"><li><a onclick="return sl(this, \'nw\', \'lln-couponbycond_2\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy2" data-start="2010-06-24T08:26:00" data-end="2011-10-31T11:08:00">Allergy Drug 2</a></li></ul></div></div><div class="coupons couponsaz"><h1>Coupons by Drug Name</h1><div class="a-to-z alpha"><ul><li class="active"><a href="#A">A</a></li><li><span>B</span></li><li><span>C</span></li><li><a href="#D">D</a></li><li><span>E</span></li><li><span>F</span></li><li><span>G</span></li><li><span>H</span></li><li><span>I</span></li><li><span>J</span></li><li><span>K</span></li><li><span>L</span></li><li><span>M</span></li><li><span>N</span></li><li><span>O</span></li><li><span>P</span></li><li><span>Q</span></li><li><span>R</span></li><li><span>S</span></li><li><span>T</span></li><li><span>U</span></li><li><span>V</span></li><li><span>W</span></li><li><span>X</span></li><li><span>Y</span></li><li><span>Z</span></li></ul><div class="tl"></div><div class="tr"></div></div><div class="a-to-z list"><ul id="couponslistA" class="active"><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_a-1\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy1" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Allergy Drug 1</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_a-2\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy2" data-start="2010-06-24T08:26:00" data-end="2011-10-31T11:08:00">Allergy Drug 2</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_a-3\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy3" data-start="2010-06-24T08:26:00" data-end="2011-10-31T11:08:00" data-neverexpires="1">Allergy Drug 3</a></li></ul><ul id="couponslistB"><li>No coupons found.</li></ul><ul id="couponslistC"><li>No coupons found.</li></ul><ul id="couponslistD"><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_d-1\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fdepressionanxiety1" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Depression &amp; Anxiety Drug 1</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_d-2\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fdiabetes1" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Diabetes Drug 1</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_d-3\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fdiabetes2" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Diabetes Drug 2</a></li></ul><ul id="couponslistE"><li>No coupons found.</li></ul><ul id="couponslistF"><li>No coupons found.</li></ul><ul id="couponslistG"><li>No coupons found.</li></ul><ul id="couponslistH"><li>No coupons found.</li></ul><ul id="couponslistI"><li>No coupons found.</li></ul><ul id="couponslistJ"><li>No coupons found.</li></ul><ul id="couponslistK"><li>No coupons found.</li></ul><ul id="couponslistL"><li>No coupons found.</li></ul><ul id="couponslistM"><li>No coupons found.</li></ul><ul id="couponslistN"><li>No coupons found.</li></ul><ul id="couponslistO"><li>No coupons found.</li></ul><ul id="couponslistP"><li>No coupons found.</li></ul><ul id="couponslistQ"><li>No coupons found.</li></ul><ul id="couponslistR"><li>No coupons found.</li></ul><ul id="couponslistS"><li>No coupons found.</li></ul><ul id="couponslistT"><li>No coupons found.</li></ul><ul id="couponslistU"><li>No coupons found.</li></ul><ul id="couponslistV"><li>No coupons found.</li></ul><ul id="couponslistW"><li>No coupons found.</li></ul><ul id="couponslistX"><li>No coupons found.</li></ul><ul id="couponslistY"><li>No coupons found.</li></ul><ul id="couponslistZ"><li>No coupons found.</li></ul><div class="foot"><div class="bl"></div><div class="br"></div></div></div><div class="footnote">If your medicine doesn\'t appear, there are no coupons currently available, but check back often as new coupons are added daily!</div></div>');

		// store objects
		this.coupons = $.extend(true, {}, webmd.m.coupons);
		this.eleaz = $('.couponsaz');
		this.elecat = $('.couponsbycat');
	});

	afterEach(function() {
		this.coupons = null;
		this.eleaz = null;
		this.elecat = null;
	});

	it("should load fixtures into the DOM", function() {
		expect( this.eleaz ).toExist();
		expect( this.elecat ).toExist();
	});

	it("hides expired links on coupon category modules unless the neverexpires attribute is set to 1", function() {
		this.coupons.init( this.elecat );
		expect( this.elecat.find('a:contains("Allergy Drug 1")') ).toExist();
		expect( this.elecat.find('a:contains("Allergy Drug 2")') ).not.toExist();
		expect( this.elecat.find('a:contains("Allergy Drug 3")') ).toExist();
	});

	it("hides expired links on coupon a-z modules", function() {
		this.coupons.init( this.eleaz );
		expect( this.eleaz.find('a:contains("Allergy Drug 1")') ).toExist();
		expect( this.eleaz.find('a:contains("Allergy Drug 2")') ).not.toExist();
	});

	it("handles empty date strings gracefully", function() {
		this.eleaz.find('a:contains("Allergy Drug 2")').attr('data-end','');
		this.coupons.init( this.eleaz );
		expect( this.eleaz.find('a:contains("Allergy Drug 1")') ).toExist();
		expect( this.eleaz.find('a:contains("Allergy Drug 2")') ).toExist();
	});

	it("handles invalid date strings gracefully", function() {
		this.eleaz.find('a:contains("Allergy Drug 2")').attr('data-end','fake');
		this.coupons.init( this.eleaz );
		expect( this.eleaz.find('a:contains("Allergy Drug 1")') ).toExist();
		expect( this.eleaz.find('a:contains("Allergy Drug 2")') ).toExist();
	});

	it("handles invalid neverexpires strings gracefully", function() {
		this.elecat.find('a:contains("Allergy Drug 3")').attr('data-neverexpires','0');
		this.coupons.init( this.elecat );
		expect( this.elecat.find('a:contains("Allergy Drug 3")') ).not.toExist();
	});

	it("handles non-existent date attributes gracefully", function() {
		this.eleaz.find('a:contains("Allergy Drug 2")').removeAttr('data-end');
		this.coupons.init( this.eleaz );
		expect( this.eleaz.find('a:contains("Allergy Drug 1")') ).toExist();
		expect( this.eleaz.find('a:contains("Allergy Drug 2")') ).toExist();
	});

});
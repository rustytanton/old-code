/**
 * CouponsAZ spec
 * 
 * @uses jquery-1.4.4
 * @uses jasmine-1.1.0
 * @uses jasmine-jquery-1.3.1
 */
describe("couponsAZ", function() {

	beforeEach(function() {

		// stubs
		webmd.url = {
			// we want the default behavior for most tests to be
			// to return an empty string if the arg is undefined. this is
			// overridden in a couple of tests when we want to
			// test hashes by modifying the return value of undefined
			getHash : function(arg) {
				if (arg !== undefined) {
					var argparts = arg.split('#');
					return argparts[1];
				} else {
					return '';
				}
			},
			setHash : function() {}
		};
		sl = function() {};
		wmdPageLink = function() {};

		// if running from a regular browser, use the last known good xml
		// (this should be updated when there are changes to the DOM output,
		// copy from build/snippets/test11.xml)
		if (document.location.protocol === 'file:' && typeof window.__phantom_writeFile === 'undefined') {
			setFixtures('<div class="coupons couponsaz"><h1>Coupons by Drug Name</h1><div class="a-to-z alpha"><ul><li class="active"><a href="#A">A</a></li><li><span>B</span></li><li><span>C</span></li><li><a href="#D">D</a></li><li><span>E</span></li><li><span>F</span></li><li><span>G</span></li><li><span>H</span></li><li><span>I</span></li><li><span>J</span></li><li><span>K</span></li><li><span>L</span></li><li><span>M</span></li><li><span>N</span></li><li><span>O</span></li><li><span>P</span></li><li><span>Q</span></li><li><span>R</span></li><li><span>S</span></li><li><span>T</span></li><li><span>U</span></li><li><span>V</span></li><li><span>W</span></li><li><span>X</span></li><li><span>Y</span></li><li><span>Z</span></li></ul><div class="tl"></div><div class="tr"></div></div><div class="a-to-z list"><ul id="couponsA" class="active"><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_a-1\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy1" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Allergy Drug 1</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_a-2\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy2" data-start="2010-06-24T08:26:00" data-end="2011-10-31T11:08:00">Allergy Drug 2</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_a-3\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fallergy3" data-start="2010-06-24T08:26:00" data-end="2011-10-31T11:08:00" data-neverexpires="1">Allergy Drug 3</a></li></ul><ul id="couponsB"><li>No coupons found.</li></ul><ul id="couponsC"><li>No coupons found.</li></ul><ul id="couponsD"><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_d-1\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fdepressionanxiety1" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Depression &amp; Anxiety Drug 1</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_d-2\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fdiabetes1" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Diabetes Drug 1</a></li><li><a onclick="return sl(this, \'nw\', \'lln-couponbydrug_d-3\');" href="http://www.webmd.com/click?url=http%3A%2F%2Fwww.externallink.com%2Fdiabetes2" data-start="2010-06-24T08:26:00" data-end="2012-10-31T11:08:00">Diabetes Drug 2</a></li></ul><ul id="couponsE"><li>No coupons found.</li></ul><ul id="couponsF"><li>No coupons found.</li></ul><ul id="couponsG"><li>No coupons found.</li></ul><ul id="couponsH"><li>No coupons found.</li></ul><ul id="couponsI"><li>No coupons found.</li></ul><ul id="couponsJ"><li>No coupons found.</li></ul><ul id="couponsK"><li>No coupons found.</li></ul><ul id="couponsL"><li>No coupons found.</li></ul><ul id="couponsM"><li>No coupons found.</li></ul><ul id="couponsN"><li>No coupons found.</li></ul><ul id="couponsO"><li>No coupons found.</li></ul><ul id="couponsP"><li>No coupons found.</li></ul><ul id="couponsQ"><li>No coupons found.</li></ul><ul id="couponsR"><li>No coupons found.</li></ul><ul id="couponsS"><li>No coupons found.</li></ul><ul id="couponsT"><li>No coupons found.</li></ul><ul id="couponsU"><li>No coupons found.</li></ul><ul id="couponsV"><li>No coupons found.</li></ul><ul id="couponsW"><li>No coupons found.</li></ul><ul id="couponsX"><li>No coupons found.</li></ul><ul id="couponsY"><li>No coupons found.</li></ul><ul id="couponsZ"><li>No coupons found.</li></ul><div class="foot"><div class="bl"></div><div class="br"></div></div></div><div class="footnote">If your medicine doesn\'t appear, there are no coupons currently available, but check back often as new coupons are added daily!</div></div>');
		}
		// when running from phantom, use the latest generated a-z xml
		else {
			jasmine.getFixtures().fixturesPath = '../build/snippets';
			loadFixtures('test11.xml');
		}

		// store objects
		this.couponsAZ = $.extend(true, {}, webmd.m.couponsAZ);
		this.ele = $('.couponsaz');
	});

	afterEach(function() {
		this.couponsAZ = null;
		this.ele = null;
	});

	it("should find 2 letters in the nav", function() {
		this.couponsAZ.init( this.ele );
		expect(this.couponsAZ.letters).toEqual(["A","D"]);
	});

	it("should show the letter A by default", function() {
		this.couponsAZ.init( this.ele );
		expect(this.couponsAZ.currentLetter).toEqual('A');
		expect( $(this.ele).find('#couponsA') ).toHaveAttr('class','active');
	});

	it("should not change the letter list when the show arg doesn't match a letter", function() {
		this.couponsAZ.init( this.ele );
		this.couponsAZ.showLetter('B');
		expect(this.couponsAZ.currentLetter).toEqual('A');
		expect( $(this.ele).find('#couponsA') ).toHaveAttr('class','active');
		expect( $(this.ele).find('#couponsB') ).not.toHaveAttr('class','active');
	});

	it("should show a letter list when the arg matches a letter with content", function() {
		this.couponsAZ.init( this.ele );
		this.couponsAZ.showLetter('D');
		expect(this.couponsAZ.currentLetter).toEqual('D');
		expect( $(this.ele).find('#couponsD') ).toHaveAttr('class','active');
		expect( $(this.ele).find('#couponsA') ).not.toHaveAttr('class','active');
	});

	it("should show a letter when there is a URL hash which matches a letter with content", function() {
		spyOn(webmd.url,"getHash").andCallFake(function(arg) {
			if (arg !== undefined) {
				var argparts = arg.split('#');
				return argparts[1];
			} else {
				return 'D';
			}
		});
		this.couponsAZ.init( this.ele );
		expect(this.couponsAZ.currentLetter).toEqual('D');
		expect( $(this.ele).find('#couponsD') ).toHaveAttr('class','active');
		expect( $(this.ele).find('#couponsA') ).not.toHaveAttr('class','active');
	});

	it("should not try to show a letter when there is a URL hash which does not match a letter with content", function() {
		spyOn(webmd.url,"getHash").andCallFake(function(arg) {
			if (arg !== undefined) {
				var argparts = arg.split('#');
				return argparts[1];
			} else {
				return 'fake';
			}
		});
		var showSpy = spyOn(this.couponsAZ, "showLetter");
		this.couponsAZ.init( this.ele );
		expect(showSpy).wasNotCalled();
	});

	it("should not try to show a letter when there is no URL hash", function() {
		var showSpy = spyOn(this.couponsAZ, "showLetter");
		this.couponsAZ.init( this.ele );
		expect(showSpy).wasNotCalled();
	});

	it("should fire the wmdTrack function when a user clicks a nav link", function() {
		this.couponsAZ.init( this.ele );
		var wmdPageLinkSpy = spyOn(window, "wmdPageLink");
		var $link = $(this.ele).find('.alpha a:contains("D")');
		$link.trigger('click');
		expect(wmdPageLinkSpy).toHaveBeenCalledWith( 'lln-couponbydrug_d' );
	});

	it("should fire the sl function when a user clicks a list link", function() {
		this.couponsAZ.init( this.ele );
		var slSpy = spyOn(window, "sl");
		var $link = $(this.ele).find('#couponsD a:contains("Diabetes Drug 1")');
		$link.trigger('click');
		expect(slSpy).toHaveBeenCalledWith( $link[0], 'nw', 'lln-couponbydrug_d-2' );
	});

});
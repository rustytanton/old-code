Coupons RSS Module
==================

This XSL is used to process a feed that comes from this URL:
http://img.webmd.com/coupons/feed.xml

That feed is generated daily using [this script](https://github.iad1.webmd.com/webmd/coupons-feed).

The module is configured in Pagebuilder by entering a number in the "Show Max. No. of Links" field:

1. Allergies Category Coupons List
2. Arthritis Category Coupons List
3. COPD Category Coupons List
4. Depression & Anxiety Category Coupons List
5. Diabetes Category Coupons List
6. Fibromyalgia Category Coupons List
7. Heart Disease Category Coupons List
8. Migraines Category Coupons List
9. Skin Problems Category Coupons List
10. Sleep Disorders Category Coupons List
11. Coupons A-Z List

Prerequisites
-------------
You must have [build tools](https://github.iad1.webmd.com/webmd/buildtools) set up, and you must checkout the root [pbmodules-rss project](https://github.iad1.webmd.com/webmd/pbmodule-rss) project to your sandbox directory.

Building
--------
The following Ant targets are available:
*	all - builds everything
*	test - generates xsl snippets and validates them, runs jasmine js tests
*	compile - minifies/concats js
*	dist - packages files for distribution
*	clean - deletes build cruft
*	doc - generates jsdoc documentation

You can invoke Ant from the command line like this:

	cd ~/sandbox/pbmodules-rss/coupons
	ant <target>

/**
 * This is temporarily required (ha) until require.js is included in scripts.js
 */
if (!image_server_url) {
	image_server_url="http://img.webmd.com/dtmcms/live";
}
require.config({
	baseUrl : image_server_url + '/webmd/consumer_assets/site_images/amd_modules'
});
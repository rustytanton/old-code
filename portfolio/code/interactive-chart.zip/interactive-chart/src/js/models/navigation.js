define(
	["jquery/1/jquery", "underscore/1/underscore", "backbone/1/backbone"],
	function($, _, Backbone) {
		return Backbone.Model.extend({
			initialize : function() {
				this.setCurrentLink();
			},
			setCurrentLink : function() {
				var self = this;
				$.each(self.get('links'), function(i, link) {
					if (link.href == window.location.pathname) {
						self.set({
							currentLinkHref : link.href,
							currentLinkText : link.title
						});
					} else if (link.href.substring(link.href.lastIndexOf('/')+1) == 'default.htm') {
						self.set({
							currentLinkHref : link.href,
							currentLinkText : link.title
						});
					}
				});
			}
		});
	}
);
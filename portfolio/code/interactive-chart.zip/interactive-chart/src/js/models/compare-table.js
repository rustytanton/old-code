/**
 * Data model: Comparison Chart Editorial Module - it's possible this could be converted to a more generic Editorial model
 */
define(
	['jquery/1/jquery','underscore/1/underscore','backbone/1/backbone'],
	function($, _, Backbone) {
		return Backbone.Model.extend({
			initialize : function() {
				var self = this;
				this.bind('change:chronicleID', function() {
					self.fetch({
						error : function() {
							self.trigger('onFetchError');
						},
						success : function() {
							self.trigger('onFetchSuccess');
						}
					});
				});
			},
			parse : function(resp, xhr) {
				
				// shortcuts
				var $module_settings = $(resp).find('webmd_rendition content wbmd_asset webmd_module module_settings');
				var $module_data = $(resp).find('webmd_rendition content wbmd_asset webmd_module module_data');
				
				// parse module data
				var module_data = {
					body_images : [],
					descriptions : [],
					links : [],
					module_title : $module_data.find('module_title').text()
				};
				$module_data.find('descriptions description').each(function(i, description) {
					module_data.descriptions.push({
						description_text : $(description).find('description_text').text()
					});
				});
				$module_data.find('links link').each(function(i, link) {
					module_data.links.push({
						action_text:  $(link).find('action_text').text(),
						link_text : $(link).find('link_text').text(),
						link_source_icon : {
							path : $(link).find('link_source_icon').attr('path')
						}
					});
				});
				$module_data.find('body_images body_image').each(function(i, body_image) {
					module_data.body_images.push({
						source : {
							path : $(body_image).find('source').attr('path')
						}
					});
				});

				// convert xml response to json, return
				return {
					module_settings : {
						title : $module_settings.find('title').text()
					},
					module_data : module_data
				};

			},
			sync : function(method, model, options) {
				if (method == 'read') {
					// params for jquery ajax call
					var params = {
						dataType : "xml",
						type : "GET",
						success : function(data) {
							options.success(data);
						}
					};
					var chronicleID = this.get('chronicleID');
					if (chronicleID) {
						params.url = '/api/repository/repositoryservice.svc/GetModuleXML?chronicleID=' + chronicleID;
						$.ajax(params);
					}
				}
			}
		});
	}
);
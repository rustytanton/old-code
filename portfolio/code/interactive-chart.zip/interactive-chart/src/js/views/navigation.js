define(
	["jquery/1/jquery", "underscore/1/underscore", "backbone/1/backbone"],
	function($, _, Backbone) {
		return Backbone.View.extend({
			events : {
				"click li a" : "navLink",
				"click .interactiveChartNavBack a" : "backLink"
			},
			initialize : function() {
				this.template = this.options.template;
				this.model.bind('change', this.render, this);
				this.render();
			},
			backLink : function(e) {
				return sl(e.currentTarget, '', 'back');
			},
			navLink : function(e) {
				var $link = $(e.currentTarget);
				var href = $link.attr("href");
				var title = $link.html();
				var route = href.substring(href.lastIndexOf('/')+1);
				if (!route) {
					route = 'default.htm';
				}
				this.trigger('route', {
					href : href,
					route : route,
					title : title
				});
				wmdPageLink( 'dyn-cnddtcmprson_' + $link.data('position') );
				return false;
			},
			render : function() {
				var html = _.template( this.template, this.model.attributes );
				this.$el.html( html );
			}
		});
	}
);
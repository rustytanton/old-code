define(
	["jquery/1/jquery", "underscore/1/underscore", "backbone/1/backbone"],
	function($, _, Backbone) {
		return Backbone.View.extend({
			events : {
				"click .interactiveChartComparisonFooterToggleSources" : "toggleSources",
				"click section a" : "bodyLink",
				"click footer a" : "footerLink"
			},
			initialize : function() {
				this.template = this.options.template;
				this.model.bind('onFetchSuccess', this.render, this);

				// the XSL renders the HTML for this initially
				if (this.options.shareBar) {
					webmd.m.share.init();
				}
			},
			bodyLink : function(e) {
				var $link = $(e.currentTarget);
				// we need to clone in case someone comes back and clicks again, probably a better way to do this
				var $clone = $link.clone();
				$clone.attr('href', this.urlFilter( $link.attr('href') ) );
				var linkCount = 1;
				var linkIndex = 1;
				var self = this;
				this.$el.find('section a').each(function() {
					if ( $(this).html() == $link.html() && $(this).attr('href') == $link.attr('href') ) {
						linkIndex = linkCount;
					}
					linkCount++;
				});
				return sl( $clone[0], 'nw', 'art-embd_' + linkIndex );
			},
			footerLink : function(e) {
				var $link = $(e.currentTarget);
				// we need to clone in case someone comes back and clicks again, probably a better way to do this
				var $clone = $link.clone();
				$clone.attr('href', this.urlFilter( $link.attr('href') ) );
				var linkCount = 1;
				var linkIndex = 1;
				var self = this;
				this.$el.find('footer a').each(function() {
					if ( $(this).html() == $link.html() && $(this).attr('href') == $link.attr('href') ) {
						linkIndex = linkCount;
					}
					linkCount++;
				});
				return sl( $clone[0], 'nw', 'art-src_' + linkIndex );
			},
			urlFilter : function(url) {
				var host = webmd.url.getHostname(url);
				if ( host.indexOf('webmd.com') === -1 ) {
					url = '/click?url=' + encodeURIComponent(url);
				}
				return url;
			},
			render : function() {
				var json = this.model.toJSON();
				json.module_data.bgImage = this.viewHelperBgImg;
				json.module_data.introText = this.viewHelperIntroText;
				json.module_data.sources = this.viewHelperSources;
				var html = _.template( this.template, json.module_data );
				this.$el.html( html );
				if (this.options.shareBar) {
					webmd.m.share.init();
				}
			},
			toggleSources : function(e) {
				if (e.currentTarget.innerHTML == "+") {
					e.currentTarget.innerHTML = "-";
				} else {
					e.currentTarget.innerHTML = "+";
				}
				this.$el.find('ol').toggle();
			},
			viewHelperBgImg : function() {
				if (_.isObject(this.body_images[0]) ) {
					return this.body_images[0].source.path;
				} else {
					return false;
				}
			},
			viewHelperSources : function() {
				if (_.isObject(this.descriptions[1]) ) {
					return this.descriptions[1].description_text;
				} else {
					return false;
				}
			},
			viewHelperIntroText : function() {
				if (_.isObject(this.descriptions[0]) ) {
					return this.descriptions[0].description_text;
				} else {
					return false;
				}
			}
		});	
	}
);
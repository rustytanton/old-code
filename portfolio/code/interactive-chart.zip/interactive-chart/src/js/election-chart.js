/**
 * Election Chart App - generic views/templates/models, custom routing
 */
define(
	[
		/* 1 */ "jquery/1/jquery",	/* 2 */ "underscore/1/underscore",
		/* 3 */ "backbone/1/backbone",	/* 4 */ "text!templates/compare-table.html",
		/* 5 */ "text!templates/navigation.html", /* 6 */ "views/compare-table",
		/* 7 */ "views/navigation", /* 8 */ "models/compare-table", /* 9 */ "models/navigation",
		/* 10 (bootstrapped by the navigation XSL) */ "data/navigation"
	],
	function(
		/* 1 */ $, /* 2 */ _, /* 3 */ Backbone, /* 4 */ TemplateCompareTable,
		/* 5 */ TemplateNav, /* 6 */ ViewCompareTable,	/* 7 */ ViewNav,
		/* 8 */ ModelCompareTable, /* 9 */ ModelNavigation, /* 10 */ DataNav
	) {

		// comparison model/view
		var compareModel = new ModelCompareTable;
		var compareView = new ViewCompareTable({
			el : $('.interactiveChartComparison'),
			model : compareModel,
			template : TemplateCompareTable,
			shareBar : true
		});

		// router
		var Router = Backbone.Router.extend({
			routes : {
				"default.htm" : "healthCareReformOverview",			
				"abortion" : "abortion",
				"health-care-costs" : "healthCareCosts",
				"medicare" : "medicare",
				"medicaid" : "medicaid",
				"pre-existing-conditions" : "preexistingConditions",
				"womens-health" : "womensHealth",
				"young-adults-health" : "youngAdultsHealth"
			},
			abortion : function() {
				compareModel.set('chronicleID', '091e9c5e80b6124a');
			},
			healthCareCosts : function() {
				compareModel.set('chronicleID', '091e9c5e80b60c2d');
			},
			healthCareReformOverview : function() {
				compareModel.set('chronicleID', '091e9c5e80b60e38');
			},
			medicaid : function() {
				compareModel.set('chronicleID', '091e9c5e80b5af3f');
			},
			medicare : function() {
				compareModel.set('chronicleID', '091e9c5e80b5af3c');
			},
			preexistingConditions : function() {
				compareModel.set('chronicleID', '091e9c5e80b60c2f');
			},
			womensHealth : function() {
				compareModel.set('chronicleID', '091e9c5e80b60c33');
			},
			youngAdultsHealth : function() {
				compareModel.set('chronicleID', '091e9c5e80b60c31');				
			}
		});
		var router = new Router;

		// navigation model/view
		var navModel = new ModelNavigation(DataNav);

		// set first link by comparing model links
		// to current href, this should be moved to nav xsl
		var navView = new ViewNav({
			el : $('.interactiveChartNav'),
			model : navModel,
			template : TemplateNav
		});
		navView.bind("route", function(params) {
			navModel.set({
				currentLinkHref : params.href,
				currentLinkText : params.title
			});
			// we don't want hashmarks in the URL for browsers
			// without pushState enabled
			if ("pushState" in window.history) {
				router.navigate(params.route, { trigger : true });
			} else {
				router[router.routes[params.route]]();
			}
		});
		$(function() {
			if ("pushState" in window.history) {
				Backbone.history.start({
					pushState: true,
					root : '/news/breaking-news/candidate-comparison/',
					silent : true
				});
			}
		});

	}
);
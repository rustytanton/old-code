({
    baseUrl: "./src/js",
    name: "election-chart",
    include: ["election-chart"],
    optimize : "none",
    out: "build/election-chart.rjsoptimized.js",
    paths : {
    	'backbone/1/backbone' : 'empty:',
    	'jquery/1/jquery' : 'empty:',
    	'underscore/1/underscore' : 'empty:',
        'data/navigation' : 'empty:'
    }
})
/**
 * SWFUpload load handler
 */
function gapn_swfupload_loaded_handler() {
	
	/* reset the form in case someone got here clicking back or forward */
	gapn_swfupload_reset_form();
	
	/* disable the submit button until a file is successfully attached */
	$('.form-submit').attr('disabled', true);
	
	/* flag SWFUpload as enabled to the Drupal form */
	$('#edit-swfupload-enabled').val(1);

	$('#gapn-swfupload-progress').html('');
	
	/* attach event to the attach button */
	$('#gapn-swfupload-attach-button').click(function(e) {
		e = e || window.event;
		if (e.stopPropagation) e.stopPropagation();
		e.cancelBubble = true;
		
		try {
			swf_upload_control.startUpload();
		} catch (ex) {

		}
		return false;
	});
	
	/* attach validate function to title and body fields on keyup */
	$('#edit-title').keyup(function() { gapn_swfupload_validate_form() });
	$('#edit-body').keyup(function() { gapn_swfupload_validate_form() });
	
	/* if there's a file error, highlight the file field */
	var errors = new Array();
	errors.push('MP3 audio needs to be encoded with a sample rate of 11025, 22050 or 44100 kHz to avoid the "chipmunk effect" in Flash.');
	errors.push('MP3 audio needs to be encoded at a constant bit rate to avoid the "chipmunk effect" in Flash.');
	
	jQuery.each(errors, function() {
		if ($('div.messages').text().match(this)) {
			$('#gapn-swfupload-file, #gapn-swfupload-browse-button').addClass('error');
		}
	});
	
	gapn_swfupload_validate_form();
}

/**
 * SWFUpload file queue handlers
 */
function gapn_swfupload_file_queued_handler(fileObj) {
	try {
		$('#gapn-swfupload-file').val(fileObj.name);
	} catch (e) {
		this.debug(e);
	}
}

function gapn_swfupload_file_queue_error_handler(fileObj, error_code, message) {
	try {
		// Handle this error separately because we don't want to create a FileProgress element for it.
		switch(error_code) {
			case SWFUpload.QUEUE_ERROR.QUEUE_LIMIT_EXCEEDED:
				alert("You have attempted to queue too many files.\n" + (message == 0 ? "You have reached the upload limit." : "You may select " + (message > 1 ? "up to " + message + " files." : "one file.")));
				return;
				break;
			case SWFUpload.QUEUE_ERROR.FILE_EXCEEDS_SIZE_LIMIT:
				alert("The file you selected is too big.");
				this.debug("Error Code: File too big, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
				return;
				break;
			case SWFUpload.QUEUE_ERROR.ZERO_BYTE_FILE:
				alert("The file you selected is empty.  Please select another file.");
				this.debug("Error Code: Zero byte file, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
				return;
				break;
			case SWFUpload.QUEUE_ERROR.INVALID_FILETYPE:
				alert("The file you choose is not an allowed file type.");
				this.debug("Error Code: Invalid File Type, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
				return;
				break;
			default:
				alert("An error occurred in the upload. Try again later.");
				this.debug("Error Code: " + error_code + ", File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
				return;
				break;
		}
	} catch (e) {
		this.debug(e);
	}
}

function gapn_swfupload_file_dialog_complete_handler(num_files_selected) {
	gapn_swfupload_validate_form();
}

/**
 * SWFUpload upload handlers
 */

function gapn_swfupload_upload_start_handler(fileObj) {
	try {
		/* fade out the form elements, fade in the progress meter */
		$('#podcast_media_file_field .description, #gapn-swfupload-file, #gapn-swfupload-attach-button').fadeOut("slow");
		$('#pmf_btn_ph_wrapper').css({'margin-left' : '-50000px'});
		
		//$('#gapn-swfupload-attach-button').fadeOut("slow", function() {
			$('#gapn-swfupload-progress').fadeIn("slow").after('<input type="button" id="swf-upload-cancel" value="Cancel" />');
			
			/* attach cancel button events */
			$('#swf-upload-cancel').click(function() {
				swf_upload_control.cancelUpload();
				$('#gapn-swfupload-file').val('');
				$('#swf-upload-cancel').fadeOut("slow");
				$('#gapn-swfupload-progress').fadeOut("slow", function() {
					$('#podcast_media_file_field .description').fadeIn("slow");
					$('#gapn-swfupload-file').fadeIn("slow", function() {
						$('#gapn-swfupload-file').css({'display' : 'inline'});
					});
					$('#gapn-swfupload-attach-button').fadeIn("slow");
					swf_upload_control.customSettings.upload_successful = false;
					$('#edit-swfupload-file-path').val('');
					$('#edit-swfupload-file-name').val('');
					$('#pmf_btn_ph_wrapper').css({'margin-left' : '0px'});
					gapn_swfupload_validate_form();
				});
			});
			
		//});
	} catch (e) {
		this.debug(e);
	}
	
	return true;
}


function gapn_swfupload_upload_progress_handler(fileObj, bytesLoaded, bytesTotal) {
	try {
		var percent = Math.ceil((bytesLoaded / bytesTotal) * 100)
		fileObj.id = "singlefile";	// This makes it so FileProgress only makes a single UI element, instead of one for each file
		var progress = new FileProgress(fileObj, this.customSettings.progress_target);
		progress.setProgress(percent);
		progress.setStatus("Uploading...<br />" + parseInt(bytesLoaded/1000) + ' / ' + parseInt(bytesTotal/1000) + ' KB');
	} catch (e) {
		this.debug(e);
	}
}

function gapn_swfupload_upload_error_handler(fileObj, error_code, message) {
	try {
		$('#gapn-swfupload-file').val('');
		gapn_swfupload_validate_form();
		
		// Handle this error separately because we don't want to create a FileProgress element for it.
		switch(error_code) {
			case SWFUpload.UPLOAD_ERROR.MISSING_UPLOAD_URL:
				alert("There was a configuration error.  You will not be able to upload a resume at this time.");
				this.debug("Error Code: No backend file, File name: " + file.name + ", Message: " + message);
				return;
				break;
			case SWFUpload.UPLOAD_ERROR.UPLOAD_LIMIT_EXCEEDED:
				alert("You may only upload 1 file.");
				this.debug("Error Code: Upload Limit Exceeded, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
				return;
				break;
			case SWFUpload.UPLOAD_ERROR.FILE_CANCELLED:
			case SWFUpload.UPLOAD_ERROR.UPLOAD_STOPPED:
				break;
			default:
				alert("An error occurred in the upload. Try again later.");
				this.debug("Error Code: " + error_code + ", File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
				return;
				break;
		}

		fileObj.id = "singlefile";	// This makes it so FileProgress only makes a single UI element, instead of one for each file
		var progress = new FileProgress(fileObj, this.customSettings.progress_target);
		progress.SetError();
		progress.ToggleCancel(false);

		switch(error_code) {
			case SWFUpload.UPLOAD_ERROR.HTTP_ERROR:
				progress.SetStatus("Upload Error");
				this.debug("Error Code: HTTP Error, File name: " + file.name + ", Message: " + message);
				break;
			case SWFUpload.UPLOAD_ERROR.UPLOAD_FAILED:
				progress.SetStatus("Upload Failed.");
				this.debug("Error Code: Upload Failed, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
				break;
			case SWFUpload.UPLOAD_ERROR.IO_ERROR:
				progress.SetStatus("Server (IO) Error");
				this.debug("Error Code: IO Error, File name: " + file.name + ", Message: " + message);
				break;
			case SWFUpload.UPLOAD_ERROR.SECURITY_ERROR:
				progress.SetStatus("Security Error");
				this.debug("Error Code: Security Error, File name: " + file.name + ", Message: " + message);
				break;
			case SWFUpload.UPLOAD_ERROR.FILE_CANCELLED:
				progress.SetStatus("Upload Cancelled");
				this.debug("Error Code: Upload Cancelled, File name: " + file.name + ", Message: " + message);
				break;
			case SWFUpload.UPLOAD_ERROR.UPLOAD_STOPPED:
				progress.SetStatus("Upload Stopped");
				this.debug("Error Code: Upload Stopped, File name: " + file.name + ", Message: " + message);
				break;
		}
	} catch (e) {
		this.debug(e);
	}
}

function gapn_swfupload_upload_success_handler(fileObj, server_data) {
	try {
		fileObj.id = "singlefile";	// This makes it so FileProgress only makes a single UI element, instead of one for each file
		var progress = new FileProgress(fileObj, this.customSettings.progress_target);
		progress.setComplete();
		progress.setStatus("Complete.");
		progress.toggleCancel(false);
		
		if (server_data === " ") {
			this.customSettings.upload_successful = false;
		} else {
			this.customSettings.upload_successful = true;
			$('#edit-swfupload-file-path').val(server_data);
			$('#edit-swfupload-file-name').val(fileObj.name);
			gapn_swfupload_validate_form();
		}
		
	} catch (e) {
		this.debug(e);
	}
}

function gapn_swfupload_upload_complete_handler(fileObj) {
	try {
		if (this.customSettings.upload_successful) {
			//whatever we want to happen when the form is done
		} else {
			fileObj.id = "singlefile";	// This makes it so FileProgress only makes a single UI element, instead of one for each file
			var progress = new FileProgress(fileObj, this.customSettings.progress_target);
			progress.SetError();
			progress.SetStatus("Upload cancelled");
			progress.ToggleCancel(false);
			
			$('#gapn-swfupload-file').val('');
			gapn_swfupload_validate_form();

		}
	} catch (e) {
		this.debug(e);
	}
}

/**
 * Validate the form
 */
function gapn_swfupload_validate_form() {
	
	/* toggle the attach button enabled/disabled */
	var is_valid = true;
	if ($('#gapn-swfupload-file').val() === '') is_valid = false;
	$('#gapn-swfupload-attach-button').attr('disabled', !is_valid);
	
	/* enable the submit button only if everything is filled in */
	if ($('#edit-title').val() != '' && $('#edit-body').val() != '' &&
	$('#edit-swfupload-file-path').val() != '' && $('#edit-swfupload-file-path').val() != 0 &&
	$('#edit-swfupload-file-name').val() != '' && $('#edit-swfupload-file-name').val() != 0
	) {
		$('.form-submit').attr('disabled', false);
	} else {
		$('.form-submit').attr('disabled', true);
	}
}

/**
 * This clears all the elements out of the form on page load. Used in case someone
 * navigates here by clicking back or forward
 */
function gapn_swfupload_reset_form() {
	$('#podcast_media_file_field .description').show();
	$('#podcast_media_file_field .form-item').show();
	$('#edit-swfupload-file-path').val('');
	$('#edit-swfupload-file-name').val('');
	swf_upload_control.cancelUpload();
	swf_upload_control.customSettings.upload_successful = false;
}
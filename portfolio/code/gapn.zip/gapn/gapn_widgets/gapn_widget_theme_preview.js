function buildPreview() { 
  var key = $('#widget_select').val();
  var itemCount = $('#widget_num_items').val();
  $('#gapn_widget_preview').fadeOut("slow");
  switch(key) {
    case 'frontpage':
	  $('#gapn_widget_preview').load(baseURL() + '/widget-preview/frontpage', { items : itemCount }).fadeIn("slow");
      break;
    case 'all_episodes':
      $('#gapn_widget_preview').load(baseURL() + '/widget-preview/episodes/all', { items : itemCount }).fadeIn("slow");
      break;
    case 'network_episodes':
      $('#gapn_widget_preview').load(baseURL() + '/widget-preview/episodes/network', { items : itemCount }).fadeIn("slow");
      break;
    case 'affiliate_episodes':
      $('#gapn_widget_preview').load(baseURL() + '/widget-preview/episodes/affiliate', { items : itemCount }).fadeIn("slow");
      break;
	default:
	  if (!isNaN(key)) {
	    $('#gapn_widget_preview').load(baseURL() + '/widget-preview/episodes/' + key, { items : itemCount, programID : key }).fadeIn("slow");
	  }
  }
}

function outputPreview(content) {
	$('#gapn_widget_preview').html(content).fadeIn("slow");	
}

$(document).ready(function() {
  $('select#widget_select').change(function() { buildPreview(); });
  $('select#widget_num_items').change(function() { buildPreview(); });
  buildPreview(); 
});
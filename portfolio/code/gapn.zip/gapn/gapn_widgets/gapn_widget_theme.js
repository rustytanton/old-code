function GAPNwidget(gapn) {
	var widgetHeader, widgetFooter, widgetSubscribeLink, widgetStylesheet;
	var widgetBody = '<div class="gapn-widget-body"><ul>';
	var isSingleProgram = false;	
	for (var key in gapn) {
		if (gapn[key].date) {
			var theDateFormatted = GAPNformatDate(gapn[key].date);
		}
		switch (gapn[key].type) {
			case 'meta':
				if (gapn[key].single_program) isSingleProgram = true;
				widgetHeader = '<div class="gapn-widget-head">';
				if (gapn[key].logo) widgetHeader += '<a href="'+gapn[key].url+'"><img alt="' + gapn[key].title + '" src="' + gapn[key].logo + '" /></a>';
				widgetHeader += '<h3><a href="'+gapn[key].url+'">' + gapn[key].title + '</a></h3>';
				widgetHeader += '</div>';
				widgetFooter = '<div class="gapn-widget-footer">';
				widgetFooter += '<a id="gapn-get-widget-link" href="http://www.gapodcastnetwork.com/goodies/widgets">Get a Georgia Podcast Network<br />widget for your website!</a>';
				widgetFooter += '</div>';
				widgetSubscribeLink = '<div id="gapn-widget-subscribe-link"><img alt="RSS" src="http://www.gapodcastnetwork.com/misc/feed.png" /> <a href="'+gapn[key].rss+'">'+gapn[key].subscribe_text+'</a></div>';
				break;
			case 'blog':
				widgetBody += '<li><a href="'+gapn[key].url+'">Blog post: ' + gapn[key].title + '</a> <span class="gapn-widget-date">' + theDateFormatted + '</span></li>';
				break;
			case 'episode':
			case 'affiliate_episode':
				widgetBody += '<li><a href="'+gapn[key].url+'">';
				if (gapn[key].program_title && !isSingleProgram) {
					widgetBody += gapn[key].program_title + ': ';
				}
				widgetBody += gapn[key].title + '</a> <span class="gapn-widget-date">' + theDateFormatted + '</span></li>';
				break;
		}
	}
	widgetBody += '</ul>'+widgetSubscribeLink+'</div>';
	return '<div class="gapn-widget">' + widgetHeader + widgetBody + widgetFooter + '</div>';
}

function GAPNformatDate(str) {
  theDate = new Date(str);
  var theMonth;
  switch (theDate.getMonth()) {
	case 0:
	  theMonth = 'Jan.';
	  break;
	case 1:
	  theMonth = 'Feb.';
	  break;
	case 2:
	  theMonth = 'March';
	  break;
	case 3:
	  theMonth = 'April';
	  break;
	case 4:
	  theMonth = 'May';
	  break;
	case 5:
	  theMonth = 'June';
	  break;
	case 6:
	  theMonth = 'July';
	  break;
	case 7:
	  theMonth = 'Aug.';
	  break;
	case 8:
	  theMonth = 'Sept.';
	  break;
	case 9:
	  theMonth = 'Oct.';
	  break;
	case 10:
	  theMonth = 'Nov.';
	  break;
	case 11:
	  theMonth = 'Dec.';
	  break;
  }
  var theHour, theAMorPM;
  theHour = theDate.getHours();
  if (theHour < 12) {
	theAMorPM = 'AM';
  } else {
	theAMorPM = 'PM';
  }
  if (theHour == 0) {
	theHour = 12;
  }
  if (theHour > 12) {
	theHour -= 12;
  }
  var theMinutes = theDate.getMinutes();
  if (theMinutes < 10) {
    theMinutes.toString();
    theMinutes = "0" + theMinutes;
  } 
  return theMonth + ' ' + theDate.getDate() + ', ' + theDate.getFullYear() + ' at ' + theHour + ':' + theMinutes + ' ' + theAMorPM;
}

document.write(GAPNwidget(gapn));